import featured_image from '../assets/img/image_8.png';

export const AdvertData = [
    {
        title : "Titre d'annonce",
        description : "Lorem Ipsum Dolor Simut Ignus, Fraks Logik Donor Lits. Lorem Ipsum Dolor Simut Ignus, Fraks Logik Donor Lits. Lorem Ipsum Dolor Simut Ignus, Fraks Logik Donor Lits. Lorem Ipsum Dolor Simut Ignus, Fraks Logik Donor Lits. Lorem Ipsum Dolor Simut Ignus, Fraks Logik Donor Lits. Lorem Ipsum Dolor Simut Ignus, Fraks Logik Donor Lits.",
        price1 : "30000 XAF",
        price2 : "49,68$Btc",
        price3 : "42,22LmCSWP",
        ads : "15",
        images : ["d", "o", "r", "e","m"],
        merchant : 'Viazizashop',
        contact1 : "652618994",
        contact2 : "694775920",
        website : "https://viaziza.com"
    }
]
