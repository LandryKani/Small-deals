export const postsData = [{
    link:"blog_details",
    text:"Lorem Ipsum is simply dummy text of the printing and typesetting...",
    time:"20 jan 2020",
    image: "/img/b1.jpg"
},
{
    link:"blog_details",
    text:"Lorem Ipsum is simply dummy text of the printing and typesetting...",
    time:"20 jan 2020",
    image: "/img/b2.jpg"
}, 
{
    link:"blog_details",
    text:"Lorem Ipsum is simply dummy text of the printing and typesetting...",
    time:"20 jan 2020",
    image: "/img/b3.jpg"
},
{
    link:"blog_details",
    text:"Lorem Ipsum is simply dummy text of the printing and typesetting...",
    time:"20 jan 2020",
    image: "/img/b1.jpg"
},
{
    link:"blog_details",
    text:"Lorem Ipsum is simply dummy text of the printing and typesetting...",
    time:"20 jan 2020",
    image: "/img/b2.jpg"
}, 
{
    link:"blog_details",
    text:"Lorem Ipsum is simply dummy text of the printing and typesetting...",
    time:"20 jan 2020",
    image: "/img/b3.jpg"
}];