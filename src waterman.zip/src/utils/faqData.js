export const faq = [
  {
    id: "1",
    question: "Buying a product",
    answer:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusantium odio perferendis, totam iusto id soluta magni, omnis doloribus ullam porro nisi ratione officiis tenetur inventore animi ut ipsam, ducimus laboriosam veniam veritatis ipsum exercitationem voluptas qui? Quidem soluta expedita autem!",
  },
  {
    id: "2",
    question: "Selling a product",
    answer:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusantium odio perferendis, totam iusto id soluta magni, omnis doloribus ullam porro nisi ratione officiis tenetur inventore animi ut ipsam, ducimus laboriosam veniam veritatis ipsum exercitationem voluptas qui? Quidem soluta expedita autem!",
  },
  {
    id: "3",
    question: "Pricing",
    answer:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusantium odio perferendis, totam iusto id soluta magni, omnis doloribus ullam porro nisi ratione officiis tenetur inventore animi ut ipsam, ducimus laboriosam veniam veritatis ipsum exercitationem voluptas qui? Quidem soluta expedita autem!",
  },
  {
    id: "4",
    question: "How to boost my ads",
    answer:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusantium odio perferendis, totam iusto id soluta magni, omnis doloribus ullam porro nisi ratione officiis tenetur inventore animi ut ipsam, ducimus laboriosam veniam veritatis ipsum exercitationem voluptas qui? Quidem soluta expedita autem!",
  },
];
