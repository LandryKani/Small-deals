export const MerchantsData = [{
    image: "/img/image1.jpg",
    name: "UN. Média", ads: "1.7K",
    description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard.",
    stars: 3,
    link:"merchant"
},
{
    image: "/img/image2.jpg",
    name: "Viaziza Tech", ads: "1.7K",
    description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard.",
    stars: 5,
    link:"merchant"
}, 
{
    image: "/img/media3.jpg",
    name: "UN. Média", ads: "1.7K",
    description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard.",
    stars: 4,
    link:"merchant"
}, 
{
    image: "/img/image4.jpg",
    name: "Viaziza Tech", ads: "1.7K",
    description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard.",
    stars: 5,
    link:"merchant"
}, 
{
    image: "/img/image1.jpg",
    name: "UN. Média", ads: "1.7K",
    description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard.",
    stars: 3,
    link:"merchant"
}, 
{
    image: "/img/image2.jpg",
    name: "Viaziza Tech", ads: "1.7K",
    description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard.",
    stars: 4,
    link:"merchant"
}, 
{
    image: "/img/media3.jpg",
    name: "UN. Média", ads: "1.7K",
    description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard.",
    stars: 3,
    link:"merchant"
}, 
{
    image: "/img/image4.jpg",
    name: "Viaziza Tech", ads: "1.7K",
    description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard.",
    stars: 5,
    link:"merchant"
}];