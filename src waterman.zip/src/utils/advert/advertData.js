// import featured_image from '../assets/img/image_8.png';

export const advertData = [
    {
        title : "Titre d'annonce",
        description : "Lorem Ipsum Dolor Simut Ignus, Fraks Logik Donor Lits. Lorem Ipsum Dolor Simut Ignus, Fraks Logik Donor Lits. Lorem Ipsum Dolor Simut Ignus, Fraks Logik Donor Lits. Lorem Ipsum Dolor Simut Ignus, Fraks Logik Donor Lits. Lorem Ipsum Dolor Simut Ignus, Fraks Logik Donor Lits. Lorem Ipsum Dolor Simut Ignus, Fraks Logik Donor Lits.",
        price1 : "30000",
        price2 : "49.68",
        price3 : "42.22",
        ads : "15",
        images : [
            "/img/im7.jpg", 
            "/img/im6.jpg", 
            "/img/Rectangle 5.png", 
            "/img/Rectangle 7.png",
            "/img/im4.jpg",
            "/img/image_8.png",
            "/img/Rectangle 8.png"
        ],
        featured_product : ["/img/im1.jpg", "/img/im4.jpg", "/img/im7.jpg", "/img/im6.jpg"],
        merchant : 'Viazizashop',
        contact1 : "652618994",
        contact2 : "694775920",
        website : "https://viaziza.com"
    }
]
