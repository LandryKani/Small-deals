import React from 'react'

function GetImages({ product, imgSelected, setImgSelected }) {
    return (
        <div>
            {product.images.map(image => {
                <li key={image.associatedVariants}>
                    <img src={image.large.url}
                        alt="image"
                        className='image_thumbs'
                        onClick={() => setImgSelected(image.large.url)}
                        style={{ border: imgSelected === image.large.url ? '1px solid #000000' : '' }}
                    />
                </li>
            })
            }
        </div>
    )

}

export default GetImages


