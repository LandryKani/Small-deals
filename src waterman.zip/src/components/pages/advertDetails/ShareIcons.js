import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { api_route } from '../../../utils/api_route.js';
import { fetch_get, fetch_post } from '../../../utils/help_functions.mjs';

function ShareIcons() {

    const [datas, setDatas] = useState(null);
    const [response, setResponse] = useState(null);
    useEffect(() => {
        fetch_post(api_route.share_product.url, datas, setResponse)
    }, []);

    const [url, setUrl] = useState('#');
    console.log(url)


    const ShareProduct = e => {
        e.preventDefault();
        const id = e.currentTarget.id;
        console.log("id : " + id)
        const social = null;
        if (response != null && (response.success == false && response.status == 405)){
            console.log(response)
            social = response.datas.social_share_links.find((social) => social.class == id)
            setUrl(social.url)
        }
    }

    return (
        <div className="share__icons">
            <p className="share__title">Partagez cette annonce:</p>
            <div className="share_icons_circle_icons">
                <Link to={url} title="twitter" id="twitter" onClick={ShareProduct}>
                    <div className="circle__icons share_icons_twitter"><i className="fa-brands fa-twitter"></i></div>
                </Link>
                <Link to={url} title="facebook" id="facebook" onClick={ShareProduct}>
                    <div className="circle__icons share_icons_facebook"><i className="fa-brands fa-facebook-f"></i></div>
                </Link>
                <Link to={url} title="youtube" id="youtube" onClick={ShareProduct}>
                    <div className="circle__icons share_icons_youtube"><i className="fa-brands fa-youtube"></i></div>
                </Link>
                <Link to={url} title="whatsapp" id="whatsapp" onClick={ShareProduct}>
                    <div className="circle__icons share_icons_whatsapp"><i className="fa-brands fa-whatsapp"></i></div>
                </Link>
            </div>
        </div>
    )
}

export default ShareIcons