import React from 'react'

function Merchant() {
  return (
    <div>I am a Merchant</div>
  )
}

export default Merchant