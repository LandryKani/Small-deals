import React from 'react'

function Annonces() {
  return (
    <div>Annonces</div>
  )
}

export default Annonces