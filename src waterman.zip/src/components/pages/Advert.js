import React from 'react'

function Advert() {
  return (
    <div>Advert</div>
  )
}

export default Advert